import numpy as np
from flask import Flask, request, jsonify, render_template
import joblib 
import pickle
from tensorflow.keras.models import load_model

ct = joblib.load("strokect")
sc = pickle.load(open("strokescaler.pkl", "rb"))
model = load_model("Stroke.h5")
app = Flask(__name__)

@app.route('/')
def home():
    return render_template('design.html')

@app.route('/predict',methods=['POST'])
def predict():
    gender = request.form['gender']

    age = request.form['age']
    
    hypertension = request.form['hypertension']
  
    
    heart_disease = request.form['heart_disease']
   
    
    ever_married = request.form['ever_married']	

    
    work_type = request.form['work_type']
  
             
    Residence_type = request.form['Residence_type']
         
    avg_glucose_level = request.form['avg_glucose_level']
    
    bmi = request.form['bmi']

    smoking_status = request.form['smoking_status']
   
    total = [[gender,int(age),int(hypertension),int(heart_disease),ever_married,work_type,Residence_type,float(avg_glucose_level),float(bmi),smoking_status]]
    p = np.array(sc.transform(ct.transform(total)))
    prediction = model.predict(p)
    prediction = prediction>0.5
    if(prediction==[[False]]):
        output = "Unlikely To Get A Stroke"
    else:
        output = "Likely To Get A Stroke"
    return render_template('design.html', prediction_text= output)


if __name__ == "__main__":
    app.run(port = 8088, debug=True)